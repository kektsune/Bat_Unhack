README for Bat_Unhack

HOW TO USE:
1. Double click the "Bat_Unhack" file to see if it's blocked
4. (IF BLOCKED) right click the "Bat_Unhack" file
5. (IF BLOCKED) go to "Properties"
6. (IF BLOCKED) check "Unblock"
7. (IF BLOCKED) click "OK"
9. Double click the "Bat_Unhack" file OR right click and find "Open"
10. The file will open in the "CMD"/"Command Prompt" with further instructions

CREDITS:
Script made by Kektsune in Batch

DOWNLOAD / RELEASES:
In case you can’t find the download or want older versions:  
Bat_Unhack v1.0.0 Release: https://github.com/kektsune/Bat_Unhack